<!-- Authors: Trevor Powell, Sanghoon Yi -->
<!-- help received from inclass assignments -->
<!-- help from https://codewithawa.com/posts/complete-user-registration-system-using-php-and-mysql-database -->
<?php
session_start();

$username = "";
$errors = array();


$db = mysqli_connect('localhost', 'root', '', 'mindtriv');

if(isset($_POST['reg_user'])){
	$username = mysqli_real_escape_string($db, $_POST['user_name']);
	$password1 = mysqli_real_escape_string($db, $_POST['pass']);
	$password2 = mysqli_real_escape_string($db, $_POST['retype_pass']);
	$country = mysqli_real_escape_string($db, $_POST['country']);

	if (empty($username)) { array_push($errors, "Username is required"); }
  // echo "username".count($errors);
  if (empty($password1)) { array_push($errors, "Password is required");}
  // echo "password".count($errors);
  if ($password1 != $password2) {
	     array_push($errors, "The two passwords do not match");
  }
  // echo "match".count($errors);

  	$mt_check_query = "SELECT * FROM tbl_mind_triv WHERE username='$username' LIMIT 1";
  	$result = mysqli_query($db, $mt_check_query);
  	$mt = mysqli_fetch_assoc($result);

  	if ($mt) { // if user exists
    	if ($mt['username'] === $username) {
      		array_push($errors, "Username already exists");
    	}
  	}



  	if (count($errors) == 0) {
  		$password = md5($password_1);

  		$query = "INSERT INTO tbl_mind_triv (username, password, country) VALUES('$username', '$password1', '$country')";
  			mysqli_query($db, $query);
  			$_SESSION['Username'] = $username;
  			$_SESSION['success'] = "You are now logged in";
  			header('location: main.php');

  		
  	}

}



?>