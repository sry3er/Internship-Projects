<!-- Authors: Trevor Powell, Sanghoon Yi -->
<!-- help received from inclass assignments -->
<?php include('connect.php')?>
<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">     <!-- require for IE -->
    <meta name="viewport" content="width=device-width, initial-scale=1">   <!-- ensure display and zoom properly, based on screen width --> 
        
    <title>Create Account - Mindless Trivia!</title>
    <style>
      a:hover { background-color:white; }
      label { padding: 4px 10px 0px 4px; }       
      .msg { margin-left:40px; font-style: italic; color: red; font-size:0.8em;}
    </style>
 
    <script type="text/javascript">
      function setFocus()
      {
        document.forms[0].elements[0].focus();
      }
    </script>
    
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  </head>

  <body onload="setFocus()">

    <header class="primary-header container">
      <div class="row">
        <div class="col-2">
          <h1 class="logo">
            <a href="main.html">Mindless Trivia!</a>
          </h1>
        </div>      
        <div class="col-10" id="fadeshow"> 
          <h3 class="tagline"></h3>
          
          
        </div>
      </div>  
    </header>
    
    <div class="row">
      <div class="col-12">
        <section class="title container">
          <h2>Play the most competitive and exciting trivia game!</h2>
        </section>
      </div>
      <nav class="nav primary-nav">   
            <ul>
              <li><a href="main.php" title="Navigate to the home page!">Home</a></li>
              <li><a href="news.html" title="Click to check recent news and updates!">News</a></li>
              <li><a href="play.html" title="Play game!">PLAY</a></li>
              <li><a href="scoreboard.html" title="Click to check and compare scores!">Scoreboard</a></li>
              <li><a href="signin.php" title="Sign in or sign up here!">Sign in/up</a></li>
            </ul>
          </nav>
    </div>
  
    <!-- highlight / showcase -->        
    <section class="content-row row">
      <div class="grid">
      
        <section class="highlight content-col col-3">
          <center>

  <h2><font color="green">Create New Account</font></h2> 

  <br>
  
    <form action="connect.php" method="post" target="_blank" onsubmit="try {return window.confirm(&quot;This form may not function properly due to certain security constraints.\nContinue?&quot;);} catch (e) {return false;}">
      <?php include('errors.php'); ?>  
      <label>Username:</label> 
             <input type="text" name="user_name" size="10px" style="text-align:right" title="Please fill out">  <br>              
              
                          
      <label> Password:</label>  
             <input type="Password" name="pass" size="10px" style="text-align:right" title="Must be at least 8 or more characters">
            
             <br>              
              
      
      <label>Retype Password</label>  
             <input type="Password" name="retype_pass" size="10px" style="text-align:right">
              
             <br>              
              
      
      <label> Country</label>   
             <input type="text" name="country" size="10px" style="text-align:right" title="Please fill out">
          
             <br>              
  
      <label>agree to terms of awesome? </label>  
      <input type="radio" name="drop_option" value="yes" checked>Yes
      <input type="radio" name="drop_option" value="no">No
      <br><br>      

      <br><br>
      <input type="submit" value="Create account" name="reg_user">   

    </form>  


</center>
        </section>
        
      </div>
    </section>   

    <footer class="primary-footer container">
      
      <nav class="nav">
        <ul>
          <li><a href="main.php" title="Navigate to the home page!">Home</a></li>
              <li><a href="news.html" title="Click to check recent news and updates!">News</a></li>
              <li><a href="play.html" title="Play game!">PLAY</a></li>
              <li><a href="scoreboard.html" title="Click to check and compare scores!">Scoreboard</a></li>
              <li><a href="signin.php" title="Sign in or sign up here!">Sign in/up</a></li>
        </ul>
      </nav>
    </footer>

  </body>
</html>
