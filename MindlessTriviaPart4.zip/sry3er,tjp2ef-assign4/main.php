<!-- Authors: Trevor Powell, Sanghoon Yi -->
<!-- help received from inclass assignments -->

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">     <!-- require for IE -->
    <meta name="viewport" content="width=device-width, initial-scale=1">   <!-- ensure display and zoom properly, based on screen width --> 
        
    <title>Home - Mindless Trivia!</title>
    
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  </head>

  <body>
    

    <header class="primary-header container">
      <div class="row">
        <div class="col-2">
          <h1 class="logo">
            <a href="main.php">Mindless Trivia!</a>
          </h1>
        </div>      
        <div class="col-10" id="fadeshow"> 
          <h3 class="tagline"></h3>
          
          
        </div>
      </div>  
    </header>
    
    <div class="row">
      <div class="col-12">
        <section class="title container">
          <h2>Play the most competitive and exciting trivia game!</h2>
        </section>
      </div>
      <?php if (isset($_SESSION['username'])) : ?>
        <h1>Welcome, <font color="green" style="font-style:italic"> <?php echo($_SESSION['username']); ?>   </font></h1>
      <?php endif ?>
        

      <nav class="nav primary-nav">   
            <ul>
              <li><a href="main.php" title="Navigate to the home page!">Home</a></li>
              <li><a href="news.html" title="Click to check recent news and updates!">News</a></li>
              <li><a href="game.html" title="Play game!">PLAY</a></li>
              <li><a href="scoreboard.html" title="Click to check and compare scores!">Scoreboard</a></li>
              <li><a href="signin.php" title="Sign in or sign up here!">Sign in/up</a></li>
            </ul>
          </nav>
    </div>
  
    <!-- highlight / showcase -->        
    <section class="content-row row">
      <div class="grid">
      
        <section class="highlight content-col col-3">
          <a href="expandmind.jpg">
            <img src="expandmind.jpg" alt="image showing highlight1"> <br/>
            <font class="subtitle">Expand Your Mind!</font>
          </a>
          <p>Learn useful and interesting facts to improve and expand your branial capacity!</p>
        </section>

        <section class="highlight content-col col-3">
          <a href="competing.png">
            <img src="competing.png" alt="image showing highlight2"> <br/>
            <font class="subtitle">Compete Against Friends!</font>
          </a>
          <p>Play for the highest score, or beat your friends on the scoreboard!</p>
        </section>
 
        <section class="highlight content-col col-3">
          <a href="thumbsup.png">
            <img src="thumbsup.png" alt="image showing highlight3"> <br/>
            <font class="subtitle">Become a Trivia God!</font>
          </a>
          <p>Impress your friends, family, and even strangers with your trivia skills!</p>
        </section>
        
      </div>
    </section>   

    <footer class="primary-footer container">
      
      <nav class="nav">
        <ul>
          <li><a href="main.php" title="Navigate to the home page!">Home</a></li>
              <li><a href="news.html" title="Click to check recent news and updates!">News</a></li>
              <li><a href="play.html" title="Play game!">PLAY</a></li>
              <li><a href="scoreboard.html" title="Click to check and compare scores!">Scoreboard</a></li>
              <li><a href="signin.php" title="Sign in or sign up here!">Sign in/up</a></li>
        </ul>
      </nav>
    </footer>

  </body>
</html>