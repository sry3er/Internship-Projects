<!-- Authors: Trevor Powell, Sanghoon Yi -->
<!-- help received from inclass assignments -->
<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">     <!-- require for IE -->
    <meta name="viewport" content="width=device-width, initial-scale=1">   <!-- ensure display and zoom properly, based on screen width --> 
        
    <title>Sign in - Mindless Trivia!</title>
    <style>
      a:hover { background-color:white; }
      label { padding: 4px 10px 0px 4px; }       
      .msg { margin-left:40px; font-style: italic; color: red; font-size:0.8em;}
    </style>
 
    <script type="text/javascript">
      function setFocus()
      {
        document.forms[0].elements[0].focus();
      }
    </script>
    
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  </head>

  <body onload="setFocus()">
    <?php
   if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: main.html");
    exit;
}
  ?>
    <header class="primary-header container">
      <div class="row">
        <div class="col-2">
          <h1 class="logo">
            <a href="main.html">Mindless Trivia!</a>
          </h1>
        </div>      
        <div class="col-10" id="fadeshow"> 
          <h3 class="tagline"></h3>
          
          
        </div>
      </div>  
    </header>
    
    <div class="row">
      <div class="col-12">
        <section class="title container">
          <h2>Play the most competitive and exciting trivia game!</h2>
        </section>
      </div>
      <nav class="nav primary-nav">   
            <ul>
              <li><a href="main.html" title="Navigate to the home page!">Home</a></li>
              <li><a href="news.html" title="Click to check recent news and updates!">News</a></li>
              <li><a href="play.html" title="Play game!">PLAY</a></li>
              <li><a href="scoreboard.html" title="Click to check and compare scores!">Scoreboard</a></li>
              <li><a href="signin.php" title="Sign in or sign up here!">Sign in/up</a></li>
            </ul>
          </nav>
    </div>
  
      
    <section class="content-row row">
      <div class="grid">
      
        <section class="highlight content-col col-3">
          <center>

  <h2><font color="green">Sign in</font></h2> 

  <br/>
  
    <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">  
      <label for="prj1">Username:</label> 
             <input type="text" name="user_name" size="10px" style="text-align:right" pattern=".{1,}" title="Must be filled" required />  <br/>              
             <!--  <input type="text" name="prj1_total" size="10px" value="100" disabled style="text-align:right" /> <span style="color:red">*</span> <br /> --> <!-- set default total possible score = 100 -->
                          
      <label for="prj2"> Password:</label>  
             <input type="Password" name="pass" size="10px" style="text-align:right" pattern=".{8,}" title="Must be at least 8 or more characters" required />
             <br/>              
   

      <br /><br />
      <input type="submit" value=" Log in" /> &nbsp;&nbsp;

    </form>  
    Don't have an account? Click <a href="createAccount.php">here</a> to create one!

        </section>
        
      </div>
    </section>   
    <?php
$message="";
if(count($_POST)>0) {
  $conn = mysqli_connect("localhost","root","","mindtriv");

  $result = mysqli_query($conn,"SELECT * FROM tbl_mind_triv WHERE username='" . $_POST["user_name"] . "' and password = '". $_POST["pass"]."'");
  $count  = mysqli_num_rows($result);
  if($count==0) {
    $message = "Invalid Username or Password!";
    echo($message);
  } else {
    session_start();
                            
                            // Store data in session variables
    $_SESSION["loggedin"] = true;
 
    $_SESSION["username"] = $username;                            
                            
    $message = "You are successfully authenticated!";
    header("location: main.php");
  }
}
?>
    <footer class="primary-footer container">
      
      <nav class="nav">
        <ul>
          <li><a href="main.php" title="Navigate to the home page!">Home</a></li>
              <li><a href="software.html" title="Click to check recent news and updates!">News</a></li>
              <li><a href="research.html" title="Play game!">PLAY</a></li>
              <li><a href="scoreboard.html" title="Click to check and compare scores!">Scoreboard</a></li>
              <li><a href="signin.php" title="Sign in or sign up here!">Sign in/up</a></li>
        </ul>
      </nav>
    </footer>
   
  </body>
</html>
