"use strcit";


class TweenableParam{
  constructor(){
    this.params = new Map();
    this.params.setPair("xpos", 0);
    this.params.setPair("ypos", 0);
    this.params.setPair("xscale", 1);
    this.params.setPair("yscale", 1);
    this.params.setPair("rotate", 0);
    this.params.setPair("alpha", 1);
  }
}
