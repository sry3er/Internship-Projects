"use strict";



class IEventDispatcher {

  constructor(){

  }

  addEventListener(listener, eventType){
    
  }

  removeEventListener(listener, eventType){

  }

  dispatchEvent(even){

  }

  hasEventListener(listener, eventType){

  }
}
