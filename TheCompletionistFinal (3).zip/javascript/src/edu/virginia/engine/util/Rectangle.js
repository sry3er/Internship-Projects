"use strict";

class Rectangle{
  constructor(x, y, wid, hei){
    this.x = x;
    this.y = y;
    this.wid = wid;
    this.hei = hei;
  }
}
