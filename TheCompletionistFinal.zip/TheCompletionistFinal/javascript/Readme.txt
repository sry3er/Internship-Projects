The Completionist - CS 4730, Summer 2018
Created by Branden Kim, Michael Klaczynski, and Sanghoon Yi