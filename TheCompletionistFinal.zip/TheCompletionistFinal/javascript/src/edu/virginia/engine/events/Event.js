"use strict";

class Event {
  constructor(name){
    this.eventType = name;
    this.source;
    this.quest;
    this.coinCount = 0;
    this.disc = "";
  }
}
